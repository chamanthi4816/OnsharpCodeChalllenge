﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingScore
{
    class Constants
    {
		public const int EMPTY = -1;

		public const int MAX_FRAMES = 12;

		public const int MAX_PINS_ROLLED = 10;

		public const int STRIKE_BONUS = 2;

		public const int SPARE_BONUS = 1;

		public const int LAST_FRAME = 10;

		public const int BONUS_FRAME1 = 11;

		public const int BONUS_FRAME2 = 12;


	}
}
