﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingScore
{
    public class Frame
    {
        public int FirstRoll { get; set; } = Constants.EMPTY;
		public int SecondRoll { get; set; } = Constants.EMPTY;
		public int Bonus { get; set; }
        public int Points { get; set; }
        public bool IsStrike { get; set; }
        public bool IsSpare { get; set; }
        public int Temp { get; set; }
	}
}
