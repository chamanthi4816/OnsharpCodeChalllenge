﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingScore
{
    class Program
    {
        static void Main(string[] args)
        {
			BowlingGame bowlingGame = new BowlingGame();

			while(!bowlingGame.isOver())
			{
				bowlingGame.Bowl(Convert.ToInt32(Console.ReadLine()));
			}

			Console.WriteLine(bowlingGame.getScore());
			Console.WriteLine(bowlingGame.isOver());

			for (int i = 0; i < bowlingGame.frames.Length; i++)
			{

				Console.Write("Attempt " + i + " - ");
				Console.Write("[" + bowlingGame.frames[i].FirstRoll + " , ");

				if (bowlingGame.frames[i].IsSpare)
					Console.Write("\\");
			else if (bowlingGame.frames[i].IsStrike)
					Console.Write("X");
			else
					Console.Write(bowlingGame.frames[i].SecondRoll);

				Console.Write("] , Temp: " + bowlingGame.frames[i].Temp);
				Console.Write(", Points: " + bowlingGame.frames[i].Points);
				Console.WriteLine();
			}

			Console.Read();
		}
    }
}
