﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BowlingScore
{
    public class BowlingGame
    {

        public Frame[] frames;

        private int attempt;

        public BowlingGame()
        {

            this.attempt = 0;
            this.frames = new Frame[Constants.MAX_FRAMES];

            for (int i = 0; i < frames.Length; i++)
            {

                this.frames[i] = new Frame();
            }
        }

        public void Bowl(int pins)
        {

            if (!isOver())
            {

                if (pins <= Constants.MAX_PINS_ROLLED)
                {

                    if (isValidRoll(pins, attempt))
                    {

                        if (attempt <= Constants.LAST_FRAME - 1)
                        {

                            frames[attempt].Temp += pins;
                        }

                        if (attempt - 2 >= 0 && frames[attempt - 2].Bonus > 0)
                        {

                            frames[attempt - 2].Temp += pins;

                            frames[attempt - 2].Bonus--;

                            if (frames[attempt - 2].Bonus == 0)
                            {

                                if (attempt - 3 >= 0)
                                {
                                    frames[attempt - 2].Points = frames[attempt - 3].Points + frames[attempt - 2].Temp;
                                }

                                else
                                {
                                    frames[attempt - 2].Points = frames[attempt - 2].Temp;
                                }
                            }
                        }

                        if (attempt - 1 >= 0 && frames[attempt - 1].Bonus > 0)
                        {

                            frames[attempt - 1].Temp += pins;

                            frames[attempt - 1].Bonus--;

                            if (frames[attempt - 1].Bonus == 0)
                            {

                                if (attempt - 2 >= 0)
                                {
                                    frames[attempt - 1].Points = frames[attempt - 2].Points + frames[attempt - 1].Temp;
                                }
                                else
                                {
                                    frames[attempt - 1].Points = frames[attempt - 1].Temp;
                                }
                            }
                        }

                        if (frames[attempt].FirstRoll == Constants.EMPTY)
                        {

                            frames[attempt].FirstRoll = pins;

                            if (isStrike(attempt))
                            {

                                frames[attempt].Bonus = Constants.STRIKE_BONUS;
                                frames[attempt].IsStrike = true;

                                attempt++;
                                return;
                            }
                            if (attempt == Constants.BONUS_FRAME1 - 1 && isSpare(Constants.LAST_FRAME - 1))
                            {

                                attempt++;
                                return;
                            }

                            if (attempt == Constants.BONUS_FRAME2 - 1 && isStrike(Constants.LAST_FRAME - 1) && isStrike(Constants.BONUS_FRAME1 - 1))
                            {
                                attempt++;
                            }
                        }
                        else
                        {
                            frames[attempt].SecondRoll = pins;

                            if (isSpare(attempt))
                            {

                                frames[attempt].Bonus = Constants.SPARE_BONUS;
                                frames[attempt].IsSpare = true;
                            }

                            else
                            {
                                if (attempt - 1 >= 0)
                                {
                                    frames[attempt].Points = frames[attempt - 1].Points + frames[attempt].Temp;
                                }

                                else
                                {
                                    frames[attempt].Points = frames[attempt].Temp;
                                }
                            }

                            attempt++;
                            return;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: Invalid Pins");
                    }
                }
                else
                {
                    Console.WriteLine("PINS down shouls be less than 10");
                }
            }
            else
            {
                Console.WriteLine("---GAME OVER---");
            }
        }

        public bool isValidRoll(int pins, int attempt)
        {

            if (frames[attempt].FirstRoll == Constants.EMPTY)
            {

                if (pins <= Constants.MAX_PINS_ROLLED)
                    return true;
                else
                    return false;

            }
            else
            {

                if (frames[attempt].FirstRoll + pins <= Constants.MAX_PINS_ROLLED)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public int getScore()
        {

            int ptr = Constants.EMPTY;

            for (int i = frames.Length - 1; i >= 0; i--)
            {

                if (frames[i].Points > 0)
                {
                    ptr = i;
                    break;
                }
            }

            if (ptr == Constants.EMPTY)
                return 0;
            else
                return frames[ptr].Points;
        }

        public bool isOver()
        {

            if (attempt <= Constants.LAST_FRAME - 1)
            {

                return false;
            }

            else if (attempt == Constants.BONUS_FRAME1 - 1)
            {

                if (isStrike(Constants.LAST_FRAME - 1) || isSpare(Constants.LAST_FRAME - 1))
                {
                    return false;
                }

                else
                {
                    return true;
                }

            }

            else if (attempt == Constants.BONUS_FRAME2 - 1)
            {
                if (isStrike(Constants.LAST_FRAME - 1) && frames[Constants.LAST_FRAME - 1].Bonus > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return true;
            }
        }
        public bool isStrike(int attempt)
        {
            return frames[attempt].FirstRoll == 10;
        }

        public bool isSpare(int attempt)
        {
            return (frames[attempt].FirstRoll + frames[attempt].SecondRoll) == 10;
        }
    }
}
